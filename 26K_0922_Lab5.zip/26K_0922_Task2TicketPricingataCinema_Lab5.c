#include <stdio.h>
int main(){
    int age;
    char day;
    float price;
    
    printf("Enter age: ");
    scanf("%d", &age);
    printf("Enter day: ");
    scanf(" %c", &day);

    if (age < 12 || age > 60) {
        if (day == 'W') {
            price = 5.0;
        } else {
            price = 7.0;
        }
    } else {
        if (day == 'W') {
            price = 10.0;
        } else {
            price = 12.0;
        }
    }
    printf("Final ticket price: $%.2f\n", price);
}

