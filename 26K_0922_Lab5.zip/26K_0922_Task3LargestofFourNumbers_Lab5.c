#include <stdio.h>
int main(){
    int X;
    int Y;
    int Z;
    int W;
    printf("Enter four numbers");
    scanf("%d%d%d%d",&X,&Y,&Z,&W);
    
    if (X > Y) {
        if (X > Z) {
            if (X > W) {
                printf("Largest: %d\n", X);
            } else {
                printf("Largest: %d\n", W);
            }
        } else {
            if (Z > W) {
                printf("Largest: %d\n", Z);
            } else {
                printf("Largest: %d\n", W);
            }
        }
    } else {
        if (Y > Z) {
            if (Y > W) {
                printf("Largest: %d\n", Y);
            } else {
                printf("Largest: %d\n", W);
            }
        } else {
            if (Z > W) {
                printf("Largest: %d\n", Z);
            } else {
                printf("Largest: %d\n", W);
            }
        }
    }
}
