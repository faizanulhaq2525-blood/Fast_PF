#include <stdio.h>
int main(){
    int mode;
    char op;
    float a, b;
    printf("Select mode");
    scanf("%d",&mode);

    switch (mode) 
	{
        case 1:
            printf("Enter operator");
            scanf(" %c", &op);
            
            printf("Enter number 1");
            scanf("%f",&a);
            
            printf("Enter number 2");
            scanf("%f",&b);

            switch (op) 
			{
                case '+': printf("Result = %.2f\n", a + b); break;
                case '-': printf("Result = %.2f\n", a - b); break;
                case '*': printf("Result = %.2f\n", a * b); break;
                case '/': printf("Result = %.2f\n", a / b); break;
                default: printf("Invalid operator\n");
            }
            break;

        case 2:
            printf("Enter s for square . r for square root: ");
            scanf(" %c", &op);
            
            printf("Enter number: ");
            scanf("%f", &a);

            switch (op) 
			{
                case 's':
                    printf("Square = %.2f\n", a * a);
                    break;
                case 'r': 
				{
                    float root = a;
                    int i;
                    for (i = 0; i < 10; i++)
					{
                        root = (root + a / root) / 2;
                	}
                    printf("Square root = %.2f\n", root);
                    break;
                }
                default:
                    printf("Invalid choice\n");
            }
            break;

        default:
            printf("Invalid mode\n");
    }

}
