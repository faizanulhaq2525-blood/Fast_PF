#include <stdio.h>
int main(){
    int account, action;

    printf("Select account (1=Savings, 2=Current): ");
    scanf("%d", &account);

    switch (account) 
	{
        case 1:
            printf("1. Deposit  2. Withdraw  3. Check Balance\n");
            printf("Choose action: ");
            scanf("%d", &action);
            switch (action) 
			{
                case 1: printf("Deposit into Savings account\n"); break;
                case 2: printf("Withdraw from Savings account\n"); break;
                case 3: printf("Check Savings balance\n"); break;
                default: printf("Invalid action\n");
            }
            break;

        case 2:
            printf("1. Deposit  2. Withdraw  3. Check Balance\n");
            printf("Choose action: ");
            scanf("%d", &action);
            switch (action) 
			{
                case 1: printf("Deposit into Current account\n"); break;
                case 2: printf("Withdraw from Current account\n"); break;
                case 3: printf("Check Current balance\n"); break;
                default: printf("Invalid action\n");
            }
            break;

        default:
            printf("Invalid account type\n");
    }
}
