#include <stdio.h>
int main(){
    char dept;
    int sem;

    printf("Select department (C, E, B): ");
    scanf(" %c", &dept);

    switch (dept) 
	{
        case 'C':
            printf("Enter semester (1 2 3): ");
            scanf("%d", &sem);
            switch (sem) {
                case 1: printf("Course: Programming Fundamentals\n"); break;
                case 2: printf("Course: Data Structures\n"); break;
                case 3: printf("Course: Database Systems\n"); break;
                default: printf("Invalid semester\n");
            }
            break;
        case 'E':
            printf("Enter semester (1 2 3): ");
            scanf("%d", &sem);
            switch (sem)
			{
                case 1: printf("Course: Circuit Theory\n"); break;
                case 2: printf("Course: Digital Electronics\n"); break;
                case 3: printf("Course: Power Systems\n"); break;
                default: printf("Invalid semester\n");
            }
            break;
        case 'B':
            printf("Enter semester (1 2 3): ");
            scanf("%d", &sem);
            switch (sem) {
                case 1: printf("Course: Principles of Management\n"); break;
                case 2: printf("Course: Accounting\n"); break;
                case 3: printf("Course: Marketing\n"); break;
                default: printf("Invalid semester\n");
            }
            break;
        default:
            printf("Invalid department\n");
    }

}
