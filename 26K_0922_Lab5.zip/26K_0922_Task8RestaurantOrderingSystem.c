#include <stdio.h>
int main(){
    int category, item;
    
    printf("Select category: ");
    scanf("%d", &category);

    switch (category) 
	{
        case 1:
            printf("1. Tea  2. Coffee  3. Juice\n");
            printf("Choose item: ");
            scanf("%d", &item);
            switch (item) {
            	
                case 1: printf("Tea - Rs. 50\n"); break;
                case 2: printf("Coffee - Rs. 80\n"); break;
                case 3: printf("Juice - Rs. 100\n"); break;
                default: printf("Invalid item\n");
            }
            break;

        case 2:
            printf("1. Biryani  2. Burger  3. Pizza\n");
            printf("Choose item: ");
            scanf("%d", &item);
            switch (item)
			 {
                case 1: printf("Biryani - Rs. 250\n"); break;
                case 2: printf("Burger - Rs. 180\n"); break;
                case 3: printf("Pizza - Rs. 400\n"); break;
                default: printf("Invalid item\n");
            }
            break;

        case 3:
            printf("1. Ice Cream  2. Cake  3. Brownie\n");
            printf("Choose item: ");
            scanf("%d", &item);
            switch (item) 
			{
                case 1: printf("Ice Cream - Rs. 120\n"); break;
                case 2: printf("Cake - Rs. 150\n"); break;
                case 3: printf("Brownie - Rs. 100\n"); break;
                default: printf("Invalid item\n");
            }
            break;

        default:
            printf("Invalid category\n");
    }

}
