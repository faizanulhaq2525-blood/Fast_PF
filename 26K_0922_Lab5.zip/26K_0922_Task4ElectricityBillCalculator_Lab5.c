#include <stdio.h>
int main(){
    int units;
    char type;
    float total;

    printf("Enter units");
    scanf("%d", &units);
    
    printf("Enter type");
    scanf(" %c", &type);

    if (type == 'D') {
        if (units <= 100) {
            total = units * 2.0;
        } else if (units <= 300) {
            total = units * 3.5;
        } else {
            total = units * 5.0;
        }
    } else {
        if (units <= 100) {
            total = units * 4.0;
        } else if (units <= 300) {
            total = units * 6.0;
        } else {
            total = units * 8.0;
        }
    }
    printf("Total bill: $%.2f\n", total);
}

