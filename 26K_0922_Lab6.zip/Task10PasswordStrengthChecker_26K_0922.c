#include <stdio.h>
int main() 
{
    char username[21];
    int i, vowels = 0, consonants = 0;

    printf("Enter username: ");
    scanf("%s", username);
    
    for (i = 0; username[i] != '\0'; i++) 
	{
        if (username[i] == 'a' || username[i] == 'e' || username[i] == 'i' || username[i] == 'o' || username[i] == 'u' || username[i] == 'A' || username[i] == 'E' || username[i] == 'I' || username[i] == 'O' || username[i] == 'U')
		 {
            vowels = vowels + 1;
        }
        else if ((username[i] >= 'a' && username[i] <= 'z') || (username[i] >= 'A' && username[i] <= 'Z')) 
		{
            consonants = consonants + 1;
        }
    }
    printf("Vowels = %d\n", vowels);
    printf("Consonants = %d\n", consonants);

    for (i = 0; username[i] != '\0'; i++) 
	{
        if (username[i] >= 'a' && username[i] <= 'z') 
		{
		username[i] = username[i] - 32;
        }
    }
    printf("Uppercase username: %s\n", username);
}
