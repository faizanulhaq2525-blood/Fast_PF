#include <stdio.h>
int main()
 {
    float temp[8];
    int i;
    float hottest, coldest, second;

    printf("Enter 8 temperature readings:\n");
    for (i = 0; i < 8; i++)
	 {
        scanf("%f", &temp[i]);
    }

    hottest = temp[0];
    coldest = temp[0];

    for (i = 1; i < 8; i++)
	 {
        if (temp[i] > hottest) hottest = temp[i];
        if (temp[i] < coldest) coldest = temp[i];
    }
    second = coldest; 
    for (i = 0; i < 8; i++) 
	{
        if (temp[i] > second && temp[i] < hottest)
		 {
            second = temp[i];
        }
    }
    printf("Hottest = %.1f\n", hottest);
    printf("Coldest = %.1f\n", coldest);
    printf("Second hottest = %.1f\n", second);
}
