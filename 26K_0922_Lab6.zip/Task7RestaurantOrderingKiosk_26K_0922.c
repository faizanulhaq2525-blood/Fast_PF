#include <stdio.h>
int main()
 {
    int choice, total = 0, item;

    do 
	{
        printf("\n1. Add Item\n");
        printf("2. Remove Item\n");
        printf("3. View Total\n");
        printf("4. Checkout\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        if (choice == 1)
		 {
            printf("Enter item price: ");
            scanf("%d", &item);
            total = total + item;
            printf("Item added.\n");
        }
        else if (choice == 2) 
		{
            printf("Enter item price to remove: ");
            scanf("%d", &item);
            total = total - item;
            printf("Item removed.\n");
        }
        else if (choice == 3) 
		{
            printf("Current total = %d\n", total);
        }
        else if (choice == 4) 
		{
            printf("Final total = %d\n", total);
            printf("Thank you!\n");
        }
        else 
		{
            printf("Invalid choice\n");
        }

    } 
	while (choice != 4);
}
