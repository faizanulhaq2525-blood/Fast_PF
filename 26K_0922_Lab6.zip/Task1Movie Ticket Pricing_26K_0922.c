#include <stdio.h>
int main(){
    int i;
    int price = 500;
    for (i = 1; i <= 10; i++) {
        printf("Show %d = Rs. %d\n", i, price);
        price = price + 50;
    }
}
