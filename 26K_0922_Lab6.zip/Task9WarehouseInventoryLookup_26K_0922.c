#include <stdio.h>
int main() 
{
    int stock[10];
    int i, search, found = 0;

    printf("Enter stock of 10 shelves:\n");
    for (i = 0; i < 10; i++) 
	{
        scanf("%d", &stock[i]);
    }

    printf("\nStock in reverse order:\n");
    for (i = 9; i >= 0; i--)
	 {
        printf("Shelf %d: %d\n", i, stock[i]);
    }

    printf("\nEnter stock count to search: ");
    scanf("%d", &search);

    for (i = 0; i < 10; i++) 
	{
        if (stock[i] == search) 
		{
            printf("Found at shelf index %d\n", i);
            found = 1;
            break;
        }
    }

    if (found == 0) 
	{
        printf("Stock count not found\n");
    }
}
