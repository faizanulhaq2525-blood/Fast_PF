#include <stdio.h>
int main() 
{
    int lvl, hours = 0;

    printf("Enter starting water level: ");
    scanf("%d", &lvl);

    while (lvl != 1) 
	{
        printf("Hour %d: %d liters\n", hours, lvl);

        if (lvl % 2 == 0)
		 {
            lvl = lvl / 2;
        } else 
		{
            lvl = 3 * lvl + 1;
        }

        hours = hours + 1;
    }

    printf("Hour %d: 1 liter\n", hours);
    printf("Total hours = %d\n", hours);
}
