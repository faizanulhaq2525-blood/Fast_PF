#include <stdio.h>
int main()
 {
	
    int years, i;
    float amount, growth;

    printf("Enter starting amount: ");
    scanf("%f", &amount);
    
    printf("Enter growth factor: ");
    scanf("%f", &growth);
    
    printf("Enter number of years: ");
    scanf("%d", &years);

    for (i = 1; i <= years; i++)
	 {
        amount = amount * growth;
        printf("After year %d: %.2f\n", i, amount);
    }

}
