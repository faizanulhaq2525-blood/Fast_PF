#include <stdio.h>
int main() 
{
    int n, i, score, total = 0;
    float average;

    printf("Enter number of students: ");
    scanf("%d", &n);

    for (i = 1; i <= n; i++) 
	{
        printf("Enter score of student %d: ", i);
        scanf("%d", &score);
        total = total + score;
    }

    average = (float)total / n;
    
    printf("Total score = %d\n", total);
    printf("Average score = %.2f\n", average);
}
