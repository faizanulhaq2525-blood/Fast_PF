#include <stdio.h>
int main() 
{
    int mark;
    do 
	{
        printf("Enter mark (0-100): ");
        scanf("%d", &mark);

        if (mark < 0 || mark > 100)
		 {
            printf("Invalid mark! Try again.\n");
        }
    } 
	while (mark < 0 || mark > 100);

    if (mark >= 50)
	 {
        printf("Pass\n");
    } else
	 {
        printf("Fail\n");
    }

}
